# Practica 1:
## Esquemas de Codificación

### Equipo:
      	Luis Gerardo Estrada García (319013832)
       	Cielo López Villalba (422050461)
       	Dulce Julieta Mora Hernández (319236448)
       	Marcos Julián Noriega Rodríguez (319284061)
       	
Usamos Python 3.10.12, corriéndolo en una versión de linux.

#### Para compilar y ejecutar los programas usamos lo siguiente:
(Los <archivo> de entrada solo pueden ser: 
	"Ejemplar1.txt", "Ejemplar2.txt", "Ejemplar3.txt", "Ejemplar4.txt"
	Respectivamente a como se encuentran en el pdf en el ejercicio 5)

- Ejercicio 2:
	python3 codificador.py <archivo>
	
- Ejercicio 3:
	python3 transformador.py <archivo> <archivo-salida>
(El nombre del archivo de salida puede ser el que querramos)

- Ejercicio 4:
	python3 euler.py <archivo>

